﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using S22.Imap;
using System.Net.Mail;
using System.IO;

namespace sort_attch
{
    class Program
    {
        public static string destinationFile;
        public static void Main(string[] args)
        {
            using (ImapClient Client = new ImapClient("imap.gmail.com", 993,"hearmeonceagain@gmail.com", "debasish007", AuthMethod.Login, true))
            {
                // This returns all messages sent since August 23rd 2012.
                IEnumerable<uint> uids = Client.Search(
                    SearchCondition.SentSince(new DateTime(2021, 5, 29))
                );
                IEnumerable<MailMessage> messages = Client.GetMessages(uids);
                foreach (var msg in messages)
                {
                    if (msg.Attachments.Count > 0)
                    {
                        foreach (var attachment in msg.Attachments)
                        {

                            byte[] allBytes = new byte[attachment.ContentStream.Length];
                            int bytesRead = attachment.ContentStream.Read(allBytes, 0, (int)attachment.ContentStream.Length);
                            //if(!attachment.Name.Contains("Logopit"))
                            //{
                            //    destinationFile = @"D:\download_attch\" + attachment.Name;
                            //}
                            destinationFile = @"D:\download_attch\" + attachment.Name;
                            BinaryWriter writer = new BinaryWriter(new FileStream(destinationFile, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None));
                            writer.Write(allBytes);
                            writer.Close();
                        }
                    }
                }

            }
        }
    }
}
